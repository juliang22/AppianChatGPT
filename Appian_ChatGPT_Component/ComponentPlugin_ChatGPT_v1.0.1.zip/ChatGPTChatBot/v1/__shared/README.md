# Shared Folder

## Introduction

> Any files/folders added here will be copied to the LATEST version of each component upon exporting this package using `sail-tools`. 
The directory structure will be maintained, and any files will be referencable via `__shared/YOUR_FILES`.